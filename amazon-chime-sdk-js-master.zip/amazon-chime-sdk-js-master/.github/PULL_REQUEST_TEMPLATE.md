**Issue #:** 

**Description of changes:**

**Testing**

1. Have you successfully run `npm run build:release` locally?
2. How did you test these changes?


By submitting this pull request, I confirm that you can use, modify, copy, and redistribute this contribution, under the terms of your choice.
